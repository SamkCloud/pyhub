#!/usr/bin/python
# rb 20090320

import optparse
import shutil
import os

open_ldap_profile = "open_ldap"
open_ldap_profile_destination = "/etc/auth-client-config/profile.d/open_ldap"
ldap_conf_file = "/etc/ldap.conf"

def install_ladp_client():
	from pyfig import Pyfig

	
	
	pyfig = Pyfig(ldap_conf_file,' ')
	
	pyfig.change('rootbinddn','cn=admin,dc=zuccabar,dc=local')
	pyfig.change('uri','ldap://10.134.27.153')
	pyfig.change('base','dc=zuccabar,dc=local')
	
	# print pyfig.config
	
	#faccio il backup del file 
	shutil.copyfile(ldap_conf_file,ldap_conf_file+".orig")
	
	pyfig.commit(ldap_conf_file,' ')
	
	#copio  il file di configurazione per auth-client-config
	shutil.copyfile(open_ldap_profile,open_ldap_profile_destination)
	
	os.system ("auth-client-config -a -p open_ldap")



def main():
	p = optparse.OptionParser()
	p.add_option('--person', '-p', default="world")
	options, arguments = p.parse_args()
	
	
	
	
	install_ladp_client()
	
	#print 'Hello %s' % options.person

if __name__ == '__main__':
	main()
